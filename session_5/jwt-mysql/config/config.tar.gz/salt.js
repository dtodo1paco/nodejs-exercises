const salt = 'themostsecretwordeverormaybenotatall89734891273897238947589347895';

module.exports = {
    salt
}
